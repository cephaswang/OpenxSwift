import Foundation

@MainActor
class ChatManager: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    private let apiService = APIService()
    
    func sendMessage(_ content: String) async {
        // Add user message
        let userMessage = ChatMessage(
            id: UUID(),
            content: content,
            isUser: true,
            timestamp: Date()
        )
        messages.append(userMessage)
        
        isLoading = true
        errorMessage = nil
        
        do {
            // Prepare conversation history for API
            let history = messages.dropLast().suffix(10).map { message in
                [
                    "role": message.isUser ? "user" : "assistant",
                    "content": message.content
                ]
            }
            
            let response = try await apiService.sendChatMessage(
                message: content,
                history: Array(history)
            )
            
            // Check if the response contains an error
            if let errorMsg = response.error {
                throw APIError.serverError
            }
            
            // Add AI response
            let aiMessage = ChatMessage(
                id: UUID(),
                content: response.message ?? "No response received",
                isUser: false,
                timestamp: Date()
            )
            messages.append(aiMessage)
            
        } catch {
            if let apiError = error as? APIError {
                errorMessage = apiError.errorDescription ?? "发送消息失败"
            } else {
                errorMessage = "发送消息失败: \(error.localizedDescription)"
            }
            // Remove the user message if there was an error
            if let lastMessage = messages.last, lastMessage.id == userMessage.id {
                messages.removeLast()
            }
        }
        
        isLoading = false
    }
    
    func clearChat() {
        messages.removeAll()
    }
}

struct ChatMessage: Identifiable, Equatable {
    let id: UUID
    let content: String
    let isUser: Bool
    let timestamp: Date
}

struct ChatResponse: Codable {
    let success: Bool
    let message: String?
    let usage: Usage?
    let error: String?
    let details: String?
    
    struct Usage: Codable {
        let promptTokens: Int?
        let completionTokens: Int?
        let totalTokens: Int?
        
        private enum CodingKeys: String, CodingKey {
            case promptTokens = "prompt_tokens"
            case completionTokens = "completion_tokens"
            case totalTokens = "total_tokens"
        }
    }
}

struct ChatRequest: Codable {
    let message: String
    let history: [[String: String]]
}