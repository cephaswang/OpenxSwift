# GPT Chat iOS SwiftUI App

## Overview

This is a native iOS chat application built with SwiftUI that enables users to have conversations with OpenAI's GPT through a PHP backend server. The app features a modern chat interface with real-time response status display, conversation history, and comprehensive error handling.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: SwiftUI with iOS 15.0+ minimum deployment target
- **Architecture Pattern**: MVVM-like structure with separate managers for different concerns
- **Core Components**:
  - `ContentView.swift`: Main chat interface with message display and input handling
  - `ChatManager.swift`: Business logic layer managing chat state and conversation flow
  - `APIService.swift`: Network layer handling HTTP communication with backend
  - `App.swift`: Application entry point and configuration

### Backend Communication
- **Protocol**: HTTP/HTTPS REST API
- **Authentication**: Token-based authentication using custom HTTP headers (`X-Client-Token`)
- **Data Format**: JSON for request/response payloads
- **Error Handling**: Comprehensive error states with user-friendly messaging

### Security Implementation
- **Token Authentication**: Shared secret token between iOS app and PHP server
- **Transport Security**: HTTPS enforcement for production environments
- **Rate Limiting**: Server-side protection (20 requests per minute per IP)
- **Security Headers**: Custom authentication headers for API access control

### Data Management
- **Local State**: In-memory conversation history using SwiftUI state management
- **No Persistence**: Conversations are session-based without local storage
- **Real-time Updates**: Live UI updates for message status and responses

## External Dependencies

### Backend Server Requirements
- **PHP Server**: PHP 8.0+ with cURL extension
- **OpenAI Integration**: Requires OpenAI API key configured as environment variable
- **Rate Limiting**: File-based storage system for request tracking

### Development Dependencies
- **Xcode**: Version 14.0+ required for SwiftUI features
- **Swift**: Version 5.7+ for modern language features
- **iOS SDK**: iOS 15.0+ for SwiftUI compatibility

### Third-party Services
- **OpenAI API**: Backend integrates with OpenAI GPT models for conversation generation
- **CORS Configuration**: Server must be configured to allow iOS app domain access

### Configuration Requirements
- **Server URL**: Must be updated in `APIService.swift` to point to actual backend
- **Authentication Token**: Shared secret must be configured in both iOS app and PHP server
- **Environment Variables**: Backend requires `OPENAI_API_KEY` and optional `CLIENT_TOKEN` configuration