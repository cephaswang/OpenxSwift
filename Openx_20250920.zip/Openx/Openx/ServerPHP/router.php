<?php
// Router script for PHP built-in server
// This ensures all requests are handled by index.php

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// For static files, let the built-in server handle them
if ($uri !== '/' && file_exists(__DIR__ . $uri)) {
    return false;
}

// All other requests go to index.php
include __DIR__ . '/index.php';
?>