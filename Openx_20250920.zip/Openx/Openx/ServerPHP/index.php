<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Client-Token, X-Request-Path');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// 啟用錯誤日誌記錄
error_reporting(E_ALL);
ini_set('log_errors', 1);

// 記錄所有請求信息
error_log("=== 新請求 ===");
error_log("Method: " . $_SERVER['REQUEST_METHOD']);
error_log("URI: " . $_SERVER['REQUEST_URI']);
error_log("Headers: " . json_encode(getallheaders()));

$request_method = $_SERVER['REQUEST_METHOD'];

// 檢查是否為聊天請求
$is_chat_request = false;
if ($request_method === 'POST') {
    $request_path = $_SERVER['HTTP_X_REQUEST_PATH'] ?? '';
    error_log("X-Request-Path header: '$request_path'");
    
    if ($request_path === '/api/chat') {
        $is_chat_request = true;
    }
}

error_log("Is chat request: " . ($is_chat_request ? 'YES' : 'NO'));

// OpenAI API key
$openai_api_key = "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";

// 認證檢查（只對聊天請求）
if ($is_chat_request) {
    $required_token = 'your-secure-client-token-123';
    $client_token = $_SERVER['HTTP_X_CLIENT_TOKEN'] ?? '';
    
    error_log("Required token: $required_token");
    error_log("Client token: $client_token");

    if ($client_token !== $required_token) {
        error_log("Token mismatch - returning 401");
        http_response_code(401);
        echo json_encode([
            'error' => 'Unauthorized. Valid client token required.',
            'details' => 'The X-Client-Token header is missing or invalid'
        ]);
        exit();
    }
    
    error_log("Token validation successful");
}

// 路由處理
if ($is_chat_request) {
    error_log("Handling chat request");
    handleChatRequest($openai_api_key);
} elseif ($request_method === 'GET') {
    error_log("Handling health check");
    handleHealthCheck();
} else {
    error_log("No matching route found");
    http_response_code(404);
    echo json_encode([
        'error' => 'Endpoint not found',
        'details' => "Use GET for health check or POST with X-Request-Path: /api/chat for chat API",
        'debug_info' => [
            'method' => $request_method,
            'is_chat_request' => $is_chat_request,
            'headers' => getallheaders()
        ]
    ]);
}

function handleHealthCheck() {
    echo json_encode([
        'status' => 'healthy',
        'message' => 'OpenAI GPT API Server is running (NEW VERSION)',
        'timestamp' => date('Y-m-d H:i:s'),
        'version' => '2.0.0'
    ]);
}

function handleChatRequest($api_key) {
    error_log("Processing chat request");
    
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['message'])) {
        error_log("Missing message in request");
        http_response_code(400);
        echo json_encode([
            'error' => 'Message is required',
            'details' => 'Request body must contain a "message" field'
        ]);
        return;
    }
    
    $user_message = trim($input['message']);
    if (empty($user_message)) {
        error_log("Empty message");
        http_response_code(400);
        echo json_encode([
            'error' => 'Message cannot be empty'
        ]);
        return;
    }
    
    $conversation_history = $input['history'] ?? [];
    
    error_log("Message: " . substr($user_message, 0, 100));
    
    // Prepare messages for OpenAI
    $messages = [];
    
    // Add system message
    $messages[] = [
        'role' => 'system',
        'content' => 'You are a helpful assistant. Respond in a conversational and friendly manner.'
    ];
    
    // Add conversation history
    foreach ($conversation_history as $msg) {
        if (isset($msg['role']) && isset($msg['content'])) {
            $messages[] = [
                'role' => $msg['role'],
                'content' => $msg['content']
            ];
        }
    }
    
    // Add current user message
    $messages[] = [
        'role' => 'user',
        'content' => $user_message
    ];
    
    // Call OpenAI API
    $response = callOpenAI($api_key, $messages);
    
    if (!$response['success']) {
        error_log("OpenAI API call failed: " . $response['error']);
        http_response_code(500);
        echo json_encode([
            'error' => $response['error'],
            'details' => $response['details'] ?? null
        ]);
        return;
    }
    
    error_log("Chat response successful");
    echo json_encode($response);
}

function callOpenAI($api_key, $messages) {
    $url = 'https://api.openai.com/v1/chat/completions';
    
    $data = [
        'model' => 'gpt-4o-mini',
        'messages' => $messages,
        'max_tokens' => 1000,
        'temperature' => 0.7
    ];
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $api_key
        ],
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CONNECTTIMEOUT => 10
    ]);
    
    $result = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);
    
    if ($result === false || !empty($curl_error)) {
        error_log("OpenAI API curl error: " . $curl_error);
        return [
            'success' => false,
            'error' => 'Network error occurred',
            'details' => $curl_error
        ];
    }
    
    $response = json_decode($result, true);
    
    if ($http_code !== 200) {
        $error_message = $response['error']['message'] ?? 'Unknown OpenAI API error';
        error_log("OpenAI API error (HTTP $http_code): " . $error_message);
        return [
            'success' => false,
            'error' => 'OpenAI API error',
            'details' => $error_message
        ];
    }
    
    if (!$response || !isset($response['choices'][0]['message']['content'])) {
        error_log("Invalid OpenAI API response structure");
        return [
            'success' => false,
            'error' => 'Invalid API response',
            'details' => 'Unexpected response format'
        ];
    }
    
    return [
        'success' => true,
        'message' => $response['choices'][0]['message']['content'],
        'usage' => $response['usage'] ?? null
    ];
}
?>
