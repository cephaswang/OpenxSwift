# iOS GPT Chat App - Configuration Guide

## Required Configuration Steps

### 1. Update Server URL
In `APIService.swift`, update the `baseURL` to your actual server address:

```swift
private let baseURL = "https://your-actual-server-domain.com"
```

### 2. Configure Authentication Token
Both the iOS app and PHP server use a shared authentication token for security.

**For the iOS App:**
In `APIService.swift`, update the client token:
```swift
request.setValue("your-secure-client-token-123", forHTTPHeaderField: "X-Client-Token")
```

**For the PHP Server:**
Set the `CLIENT_TOKEN` environment variable on your server, or the default token will be used.

### 3. Security Recommendations

1. **Change the default token**: Replace `your-secure-client-token-123` with a strong, unique token
2. **Use environment variables**: Store the token as an environment variable on your server
3. **Regular token rotation**: Change the token periodically for enhanced security
4. **HTTPS only**: Always use HTTPS in production to protect the token in transit

### 4. Server Requirements

- PHP 8.0+ with cURL extension
- OpenAI API key set as `OPENAI_API_KEY` environment variable
- Client authentication token as `CLIENT_TOKEN` environment variable (optional)

### 5. Rate Limiting

The server implements rate limiting:
- 20 requests per minute per IP address
- File-based storage with atomic writes
- Returns HTTP 429 when limit exceeded

### 6. Testing

Test your configuration:
1. Update the baseURL in the iOS app
2. Build and run the app on a device or simulator
3. Send a test message to verify connectivity
4. Check that authentication and rate limiting work correctly