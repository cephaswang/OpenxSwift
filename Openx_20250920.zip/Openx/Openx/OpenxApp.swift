//
//  OpenxApp.swift
//  Openx
//
//  Created by admin on 2025/9/20.
//

import SwiftUI

@main
struct OpenxApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
