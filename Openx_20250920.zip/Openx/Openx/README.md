# GPT Chat iOS SwiftUI App

这是一个使用SwiftUI构建的iOS聊天应用，可以与您的PHP后端服务器通信，进行OpenAI GPT对话。

## 功能特性

- 现代化的SwiftUI聊天界面
- 与PHP后端的HTTP通信
- 支持对话历史记录
- 实时响应状态显示
- 错误处理和用户友好的提示

## 系统要求

- iOS 15.0+
- Xcode 14.0+
- Swift 5.7+

## 安装和设置

1. 在Xcode中打开项目
2. 确保选择了正确的开发团队和Bundle Identifier
3. 在 `APIService.swift` 文件中更新 `baseURL` 为您的PHP服务器地址：
   ```swift
   private let baseURL = "https://your-actual-server-domain.com"
   ```
4. 构建并运行应用

## 项目结构

- `App.swift` - 应用主入口点
- `ContentView.swift` - 主聊天界面
- `ChatManager.swift` - 聊天逻辑管理
- `APIService.swift` - HTTP API通信服务

## 使用说明

1. 启动应用后，您将看到一个聊天界面
2. 在底部输入框中输入消息
3. 点击发送按钮与GPT进行对话
4. 应用会显示您的消息和AI的回复
5. 支持查看消息发送时间

## 网络配置

确保您的PHP服务器配置了正确的CORS头部，以允许iOS应用访问API端点。

## 故障排除

- 如果连接失败，请检查服务器URL是否正确
- 确保您的设备可以访问指定的服务器地址
- 检查服务器是否正在运行且配置正确