import Foundation

class APIService {
    // 設定為你的本地伺服器地址
    private let baseURL = "http://192.168.1.103/Openx"
    private let session: URLSession
    
    init() {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 30
        config.timeoutIntervalForResource = 60
        self.session = URLSession(configuration: config)
    }
    
    // Get client token from secure storage or configuration
    private var clientToken: String {
        // Option 1: From Info.plist
        if let token = Bundle.main.infoDictionary?["CLIENT_TOKEN"] as? String {
            return token
        }
        
        // Option 2: From UserDefaults (for development)
        if let token = UserDefaults.standard.string(forKey: "CLIENT_TOKEN") {
            return token
        }
        
        // Fallback - 與你的伺服器端匹配的令牌
        return "your-secure-client-token-123"
    }
    
    func sendChatMessage(message: String, history: [[String: String]] = []) async throws -> ChatResponse {
        // 直接訪問 index.php 文件
        guard let url = URL(string: "\(baseURL)/index.php") else {
            throw APIError.invalidURL
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(clientToken, forHTTPHeaderField: "X-Client-Token")
        
        // 添加路徑信息頭部，告訴伺服器這是聊天 API 請求
        request.setValue("/api/chat", forHTTPHeaderField: "X-Request-Path")
        
        // 添加調試輸出
        print("🚀 發送請求到: \(url)")
        print("🔑 使用令牌: \(clientToken)")
        print("📝 請求頭部: \(request.allHTTPHeaderFields ?? [:])")
        
        let requestBody = ChatRequest(message: message, history: history)
        
        do {
            request.httpBody = try JSONEncoder().encode(requestBody)
            print("💬 請求內容: \(String(data: request.httpBody!, encoding: .utf8) ?? "無法顯示")")
        } catch {
            throw APIError.encodingError(error)
        }
        
        do {
            let (data, response) = try await session.data(for: request)
            
            // 打印響應以便調試
            if let responseString = String(data: data, encoding: .utf8) {
                print("📥 伺服器響應: \(responseString)")
            }
            
            guard let httpResponse = response as? HTTPURLResponse else {
                throw APIError.invalidResponse
            }
            
            print("📊 HTTP 狀態碼: \(httpResponse.statusCode)")
            
            // Enhanced error handling for token issues
            switch httpResponse.statusCode {
            case 200...299:
                do {
                    let chatResponse = try JSONDecoder().decode(ChatResponse.self, from: data)
                    return chatResponse
                } catch {
                    print("❌ JSON 解析錯誤: \(error)")
                    throw APIError.decodingError(error)
                }
                
            case 400:
                if let errorResponse = try? JSONDecoder().decode(ServerErrorResponse.self, from: data) {
                    print("❌ 400 錯誤: \(errorResponse.error)")
                    throw APIError.serverErrorWithMessage(errorResponse.error, errorResponse.details)
                }
                throw APIError.badRequest
                
            case 401:
                // Specific handling for token validation errors
                if let errorResponse = try? JSONDecoder().decode(ServerErrorResponse.self, from: data) {
                    print("🔐 認證錯誤: \(errorResponse.error)")
                    if errorResponse.error.contains("token") || errorResponse.error.contains("auth") {
                        throw APIError.invalidToken
                    }
                    throw APIError.serverErrorWithMessage(errorResponse.error, errorResponse.details)
                }
                throw APIError.unauthorized
                
            case 403:
                print("🚫 403 禁止訪問")
                throw APIError.forbidden
                
            case 429:
                if let errorResponse = try? JSONDecoder().decode(ServerErrorResponse.self, from: data) {
                    print("⏰ 限流錯誤: \(errorResponse.error)")
                    throw APIError.serverErrorWithMessage(errorResponse.error, errorResponse.details)
                }
                throw APIError.rateLimited
                
            case 500:
                if let errorResponse = try? JSONDecoder().decode(ServerErrorResponse.self, from: data) {
                    print("💥 伺服器錯誤: \(errorResponse.error)")
                    throw APIError.serverErrorWithMessage(errorResponse.error, errorResponse.details)
                }
                throw APIError.serverError
                
            default:
                print("❌ HTTP 錯誤 \(httpResponse.statusCode)")
                throw APIError.httpError(httpResponse.statusCode)
            }
            
        } catch let error as APIError {
            throw error
        } catch {
            print("🌐 網路錯誤: \(error)")
            throw APIError.networkError(error)
        }
    }
    
    func checkServerHealth() async throws -> Bool {
        // 健康檢查直接訪問 index.php
        guard let url = URL(string: "\(baseURL)/index.php") else {
            throw APIError.invalidURL
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 10
        
        print("🏥 檢查伺服器健康狀態: \(url)")
        
        do {
            let (data, response) = try await session.data(for: request)
            
            // 打印健康檢查響應
            if let responseString = String(data: data, encoding: .utf8) {
                print("🏥 健康檢查響應: \(responseString)")
            }
            
            guard let httpResponse = response as? HTTPURLResponse else {
                return false
            }
            
            print("🏥 健康檢查狀態碼: \(httpResponse.statusCode)")
            return httpResponse.statusCode == 200
        } catch {
            print("🏥 健康檢查錯誤: \(error)")
            throw APIError.networkError(error)
        }
    }
}

struct ServerErrorResponse: Codable {
    let error: String
    let details: String?
}

enum APIError: LocalizedError {
    case invalidURL
    case encodingError(Error)
    case decodingError(Error)
    case networkError(Error)
    case invalidResponse
    case badRequest
    case unauthorized
    case forbidden
    case invalidToken
    case serverError
    case serverErrorWithMessage(String, String?)
    case rateLimited
    case httpError(Int)
    
    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "無效的伺服器地址"
        case .encodingError:
            return "請求數據編碼失敗"
        case .decodingError:
            return "響應數據解析失敗"
        case .networkError(let error):
            return "網路連接錯誤: \(error.localizedDescription)"
        case .invalidResponse:
            return "伺服器響應無效"
        case .badRequest:
            return "請求參數錯誤"
        case .unauthorized:
            return "認證失敗"
        case .forbidden:
            return "訪問被禁止"
        case .invalidToken:
            return "客戶端令牌無效，請檢查配置"
        case .serverError:
            return "伺服器內部錯誤"
        case .serverErrorWithMessage(let message, let details):
            if let details = details {
                return "\(message): \(details)"
            }
            return message
        case .rateLimited:
            return "請求過於頻繁，請稍後再試"
        case .httpError(let code):
            return "HTTP錯誤: \(code)"
        }
    }
}
